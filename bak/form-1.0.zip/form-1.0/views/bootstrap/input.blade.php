

<div class="form-group">
    <label>{{$label}}</label>
    <input @foreach($attribute as $k=>$v) {{$k}}="{{$v}}" @endforeach name="{{$name}}" value="{{$value}}">
</div>