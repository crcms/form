<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 2016/11/10
 * Time: 9:02
 */

namespace CrCms\Form;


class FormRender
{

    /**
     * @var FormRenderInterface|null
     */
    protected $render = null;

    /**
     * @var array
     */
    protected $allowAttributes = ['input','textarea','select','checkbox','radio'];


    /**
     * FormRender constructor.
     * @param FormRenderInterface $render
     */
//    public function __construct(FormRenderInterface $render)
//    {
//        $this->render = $render;
//    }

    /*
     *
     * 'name'=>[
     *      'type'=>'input'
     *      'attribute'=>[
     *          'type'=>'text'
     *          'name'=>'name',
     *          'class'=>'form-control',
     *          'id'=>'_name',
     *      ]
     * ],
     * 'status'=>[
     *      'type'=>'radio'
     *      'attribute'=>[
     *          'name'=>'name',
     *          'class'=>'form-control',
     *          'id'=>'_name',
     *          'value'=>1,
     *          'option'=>[]
     *      ],
     * ]
     * 'test'=>[
     *      'type'=>'checkbox'
     *      'attribute'=>[
     *          'name'=>'checkbox',
     *          'class'=>'form-control',
     *          'option'=>[]
     *          'value'=>[1=>'ok',2=>'no']
     *      ],
     * ]
     *
     *
     * field=>[
     *      'resolve'=>'input',
     *      'view'=>'input',
     *      'attribute'=>[
     *          'id'=>'id',
     *          'name'=>'',
     *          'class'=>'',
     *          'value'=>1
     *      ],
     *      'label'=>$label
     *      'option'=>[] select or checkbox or radio //
     * ]
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     *
     */

    /**
     * @param array $attributes
     * @param array $values
     * @return array
     */
    public function render(FormConfigInterface $formConfig,array $values = []) : array
    {

        $data = [];

        $attributes = $formConfig->attributes();

        foreach ($attributes as $key=>$attribute)
        {
            if (empty($attribute['drive']))
            {
                continue;
            }

            $drive = new $attribute['drive'];

            $data[$key] = $drive->render($attribute,$key,$values[$key] ?? null);
        }

        return $data;
//
//
//        $html = [];
//
//        foreach ($attributes as $key=>$attribute)
//        {
//            $html[$key] = call_user_func_array([app($attribute['resolve']),'resolve'],[$attribute,$key,$values[$key] ?? null]);
//
////            if (!in_array($attribute['type'],$this->allowAttributes,true))
////            {
////                continue;
////            }
////
////            $html[$key] = call_user_func_array([$this->render,$attribute['type']],[$attribute,$key,$values[$key] ?? null]);
//        }
//
//        return $html;
//
//        foreach ($attributes as $key=>$attribute)
//        {
//            if (!in_array($attribute['type'],$this->allowAttributes,true))
//            {
//                continue;
//            }
//
//            $html[$key] = call_user_func_array([$this->render,$attribute['type']],[$attribute['attribute'],$values[$key]]);
//        }
//
//        return $html;
    }

}