<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 2016/11/9
 * Time: 17:00
 */

namespace CrCms\Form\RenderDrives;


use CrCms\Form\FormRenderInterface;

class Render implements FormRenderInterface
{

    /**
     * @param array $attributes
     * @return string
     */
    protected function resolveAttribute(array $attributes,string $name,$value = null) : array
    {
        $view = 'form::'.config('form.view').'.'.($attributes['view'] ?? $attributes['type']);
        $attribute = $attributes['attribute'];
        $value = $value ?? $attributes['value'] ?? null;
        $option = $attributes['option'] ?? [];
        $name = $attributes['name'] ?? $name;
        $label = $attributes['label'] ?? null;
        return compact('view','attribute','value','option','name','label');
    }


    /**
     * @param array $attributes
     * @param string $value
     * @return string
     */
/*field=>[
*      'type'=>'input',
*      'view'=>'input',
*      'attribute'=>[
*          'id'=>'id',
*          'name'=>'',
*          'class'=>'',
*      ],
 *      'value'=>1
*      'option'=>[] select or checkbox or radio //
* ]*/
    public function input(array $attributes, string $name,$value = '') : string
    {
        $attributes = $this->resolveAttribute($attributes,$name,$value);
        return view($attributes['view'],$attributes);
    }


    /**
     * @param array $attributes
     * @param string $value
     * @return string
     */
    public function textarea(array $attributes, string $name,$value = '') : string
    {
        $attributes = $this->resolveAttribute($attributes,$name,$value);
        return view($attributes['view'],$attributes);
    }


    /**
     * @param array $attributes
     * @param string|int $value
     * @return string
     */
    public function radio(array $attributes, string $name,$value = '') : string
    {
        $attributes = $this->resolveAttribute($attributes,$name,$value);
        return view($attributes['view'],$attributes);
    }


    /**
     * @param array $attributes
     * @param array $value
     * @return string
     */
    public function checkbox(array $attributes,string $name,array $value = []) : string
    {
        $attributes = $this->resolveAttribute($attributes,$name,$value);
        return view($attributes['view'],$attributes);
    }


    /**
     * @param array $attributes
     * @param array $value
     * @return string
     */
    public function select(array $attributes, string $name, $value = '') : string
    {
        $attributes = $this->resolveAttribute($attributes,$name,$value);
        return view($attributes['view'],$attributes);
    }

}