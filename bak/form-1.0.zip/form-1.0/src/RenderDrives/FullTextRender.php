<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 16-11-27
 * Time: 上午10:02
 */

namespace CrCms\Form\RenderDrives;


use CrCms\Form\FormAttributeTrait;
use CrCms\Form\FormRenderInterface;

class FullTextRender implements FormRenderInterface
{

    use FormAttributeTrait;

    protected $view = 'full-text';

}