<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 16-11-22
 * Time: 下午9:25
 */

namespace CrCms\Form\RenderDrives;


use CrCms\Form\FormAttributeTrait;
use CrCms\Form\FormRenderInterface;

class SelectRender implements FormRenderInterface
{

    use FormAttributeTrait {
        render as renderFt;
    }

    /**
     * @var string
     */
    protected $view = 'select';


    /**
     * @param array $attributes
     * @param string $name
     * @param null $value
     * @return string
     */
    public function render(array $attributes, string $name, $value = null) : string
    {
        $this->resolveAttribute($attributes,$name,(array)$value);

        //select多选
        $this->name = isset($this->attribute['multiple']) ? $this->name.'[]' : $this->name;

        $this->value = (array)$value;

        return view($this->view,get_object_vars($this));
    }

}