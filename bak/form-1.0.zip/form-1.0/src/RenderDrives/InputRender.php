<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 16-11-22
 * Time: 下午9:25
 */

namespace CrCms\Form\RenderDrives;


use CrCms\Form\FormAttributeTrait;
use CrCms\Form\FormRenderInterface;

class InputRender implements FormRenderInterface
{

    use FormAttributeTrait;

    /**
     * @var string
     */
    protected $view = 'input';

    /**
     * 'text'=>[
            'drive'=>\CrCms\Form\RenderDrives\InputRender::class,
            'attribute'=>[
            'class'=>'form-control',
            ],
            'value'=>'abc',
            'name'=>'name1',
            'label'=>'Name',
     *      'tip'=>'Tips',
     *
     * ]
     *
     *
     *
     */


}