<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 16-11-22
 * Time: 下午9:25
 */

namespace CrCms\Form\RenderDrives;


use CrCms\Form\FormAttributeTrait;
use CrCms\Form\FormRenderInterface;

class CheckboxRender implements FormRenderInterface
{

    use FormAttributeTrait;

    /**
     * @var string
     */
    protected $view = 'checkbox';

    /**
     * @var array
     */
    protected $valueKey = [];


    /**
     * @param array $attributes
     * @param string $name
     * @param null $value
     * @return string
     */
    public function render(array $attributes, string $name, $value = null): string
    {
        $this->resolveAttribute($attributes,$name,$value);

        $this->value = (array)$this->value;

        $this->valueKey = array_flip($this->value);

        return view($this->view,get_object_vars($this));
    }


}