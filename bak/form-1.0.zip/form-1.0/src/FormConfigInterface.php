<?php

namespace CrCms\Form;


interface FormConfigInterface
{

    /**
     * @return array
     */
    public function attributes() : array ;


    /**
     * @return array
     */
    public function rules() : array ;


    /**
     * @return string
     */
    public function table() : string ;


    public function hash() : string ;

}