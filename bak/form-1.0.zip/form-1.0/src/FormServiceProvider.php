<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 2016/11/9
 * Time: 16:27
 */

namespace CrCms\Form;


use Illuminate\Support\ServiceProvider;

class FormServiceProvider extends ServiceProvider
{

    /**
     * @var bool
     */
    protected $defer = false;

    /**
     * @var string
     */
    protected $configPath = __DIR__.'/../config/form.php';

    /**
     * @var string
     */
    protected $viewPath = __DIR__.'/../views';

    /**
     * @var string
     */
    protected $assetPath = __DIR__.'/../assets';


    /**
     *
     */
    public function boot()
    {
        //加载视图
        $this->loadViewsFrom($this->viewPath,'form');

        //移动目录
        $this->publishes([
            $this->configPath => config_path('form.php'),
            $this->viewPath => base_path('resources/views/vendor/'.'form'),
            $this->assetPath => public_path('vendor'),
        ]);
    }


    /**
     *
     */
    public function register()
    {
        //合并filter config
        $this->mergeConfigFrom($this->configPath, 'form');

        $this->app->bind(FormRenderInterface::class,$this->app['config']['form']['drive']);
    }


    /**
     * @return array
     */
    public function provides()
    {
        return [
            FormRenderInterface::class,
        ];
    }

}