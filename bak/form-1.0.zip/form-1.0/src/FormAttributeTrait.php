<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 16-11-22
 * Time: 下午9:36
 */

namespace CrCms\Form;


trait FormAttributeTrait
{
    /**
     * @var string
     */
    protected $value = '';

    /**
     * @var array
     */
    protected $option = [];

    /**
     * @var string
     */
    protected $label = '';

    /**
     * @var string
     */
    protected $name = '';

    /**
     * @var array
     */
    protected $attribute = [];


    /**
     * @param array $attributes
     * @return string
     */
    protected function resolveAttribute(array $attributes,string $name,$value = null)
    {
        $this->view = 'form::'.config('form.view').'.'.($attributes['view'] ?? $this->view);
        $this->attribute = $attributes['attribute'] ?? [];
        $this->value = empty($value) ? ($attributes['value'] ?? null) : $value;
        $this->option = $attributes['option'] ?? [];
        $this->name = $attributes['name'] ?? $name;
        $this->label = $attributes['label'] ?? null;
        $this->tip = $attributes['tip'] ?? null;

        return $this;
    }


    /**
     *
     */
    public function render(array $attributes, string $name, $value = null): string
    {
        $this->resolveAttribute($attributes,$name,$value);
        return view($this->view,get_object_vars($this));
    }
}