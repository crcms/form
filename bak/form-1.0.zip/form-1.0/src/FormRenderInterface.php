<?php
/**
 * Created by PhpStorm.
 * User: simon
 * Date: 2016/11/9
 * Time: 16:55
 */

namespace CrCms\Form;


interface FormRenderInterface
{

    /**
     * @param array $attributes
     * @param null $value
     * @return string
     */
    public function render(array $attributes,string $name,$value = null) : string ;

}