<?php

namespace CrCms\Form;


use Illuminate\Database\Eloquent\Model;

interface FormBehaviorInterface
{

    /**
     * @param array $data
     * @return array
     */
    public function store(array $data) : Model ;


    /**
     * @param array $data
     * @param $id
     * @return array
     */
    public function update(array $data,$id) : Model ;


    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id);

}